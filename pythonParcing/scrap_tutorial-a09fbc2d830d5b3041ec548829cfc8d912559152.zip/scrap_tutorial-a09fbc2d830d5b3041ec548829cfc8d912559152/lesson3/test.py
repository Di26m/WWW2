url = "http://www.edutainme.ru/edindex/edindex/project/01math/"

url = url.split("/")[-2]
print(url)