proxies = {
    "https": "your_proxy_ip:port"
}
