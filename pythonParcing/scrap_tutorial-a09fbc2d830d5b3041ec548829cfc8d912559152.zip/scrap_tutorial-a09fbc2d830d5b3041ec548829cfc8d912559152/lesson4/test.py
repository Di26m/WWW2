str1 = "Name: Whitby Pavilion"
str2 = "Venue short url: https://www.skiddle.com/venues/545/"
print(str1.split(":", 1))
print(str2.split(":", 1))
